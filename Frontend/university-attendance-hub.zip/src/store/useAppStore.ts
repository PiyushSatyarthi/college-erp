import { create } from 'zustand';

export type Role = 'Admin' | 'HOD' | 'Faculty' | 'Student' | 'Parent' | 'Public';

interface AppState {
  role: Role;
  setRole: (role: Role) => void;
  isDarkMode: boolean;
  toggleDarkMode: () => void;
  sidebarOpen: boolean;
  setSidebarOpen: (open: boolean) => void;
}

export const useAppStore = create<AppState>((set) => ({
  role: 'Public',
  setRole: (role) => set({ role }),
  isDarkMode: false,
  toggleDarkMode: () => set((state) => {
    const newDarkMode = !state.isDarkMode;
    if (newDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    return { isDarkMode: newDarkMode };
  }),
  sidebarOpen: window.innerWidth >= 768,
  setSidebarOpen: (open) => set({ sidebarOpen: open }),
}));
