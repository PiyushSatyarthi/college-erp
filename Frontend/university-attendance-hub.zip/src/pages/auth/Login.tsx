import React from 'react';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { Mail, Lock, Sun, Moon } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAppStore } from '@/store/useAppStore';

export function Login() {
  const navigate = useNavigate();
  const { setRole, isDarkMode, toggleDarkMode } = useAppStore();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate login for dev purposes, just default to Admin or keep it simple.
    // Real app would validate credentials.
    setRole('Admin');
    navigate('/admin');
  };

  return (
    <div className="relative flex min-h-screen items-center justify-center p-4 bg-slate-50 dark:bg-slate-950 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] dark:bg-[url('https://www.transparenttextures.com/patterns/stardust.png')] bg-opacity-20">
      <div className="absolute top-4 right-4 z-10">
        <Button variant="ghost" size="icon" onClick={toggleDarkMode}>
          {isDarkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
        </Button>
      </div>
      <Card className="w-full max-w-md shadow-xl border-slate-200/50 dark:border-slate-800/50 backdrop-blur-sm bg-white/90 dark:bg-slate-900/90">
        <CardHeader className="space-y-3 text-center pt-8">
          <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-2xl bg-blue-600 text-2xl font-bold text-white shadow-lg">
            SV
          </div>
          <CardTitle className="text-2xl font-bold tracking-tight">Shri Vivekanand College</CardTitle>
          <CardDescription className="text-sm">Attendance & Marks Management</CardDescription>
        </CardHeader>
        <CardContent>
          <form className="space-y-4" onSubmit={handleLogin}>
            <div className="space-y-2">
              <h2 className="text-xl font-semibold mb-4">Welcome back</h2>
              <div className="relative">
                <Mail className="absolute left-3 top-2.5 h-5 w-5 text-slate-400" />
                <input
                  type="email"
                  placeholder="name@college.ac.in"
                  className="w-full rounded-lg border border-slate-300 bg-white py-2 pl-10 pr-4 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500 dark:border-slate-700 dark:bg-slate-950 dark:focus:border-blue-500"
                  required
                />
              </div>
            </div>
            <div className="space-y-2">
              <div className="relative">
                <Lock className="absolute left-3 top-2.5 h-5 w-5 text-slate-400" />
                <input
                  type="password"
                  placeholder="••••••••"
                  className="w-full rounded-lg border border-slate-300 bg-white py-2 pl-10 pr-4 focus:border-blue-500 focus:outline-none focus:ring-1 focus:ring-blue-500 dark:border-slate-700 dark:bg-slate-950 dark:focus:border-blue-500"
                  required
                />
              </div>
              <div className="text-right">
                <a href="#" className="text-sm text-blue-600 hover:underline dark:text-blue-400 font-medium">
                  Forgot password?
                </a>
              </div>
            </div>
            <Button type="submit" className="w-full h-11 text-base">
              Login
            </Button>
          </form>
          
          <div className="my-6 flex items-center">
            <div className="flex-1 border-t border-slate-200 dark:border-slate-700"></div>
            <span className="mx-4 text-sm text-slate-500 dark:text-slate-400">or</span>
            <div className="flex-1 border-t border-slate-200 dark:border-slate-700"></div>
          </div>
          
          <Button variant="outline" className="w-full">
            🔗 Login with Magic Link
          </Button>
        </CardContent>
        <CardFooter className="flex flex-col items-center justify-center pb-8 pt-4">
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Shri Vivekanand College of Engineering <br/> Version 1.0.0
          </p>
        </CardFooter>
      </Card>
    </div>
  );
}
